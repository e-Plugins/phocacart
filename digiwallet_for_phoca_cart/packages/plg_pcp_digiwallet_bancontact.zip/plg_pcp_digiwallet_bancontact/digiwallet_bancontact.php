<?php
/**
 * Activates iDEAL, Bancontact, Sofort Banking, Visa / Mastercard Credit cards, PaysafeCard, AfterPay, BankWire, PayPal and Refunds in Phoca Cart
 * @author DigiWallet.nl <techsupport@targetmedia.nl>
 * @url https://www.digiwallet.nl
 * @copyright Copyright (C) 2021 e-plugins.nl
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * @ver 1.0 - 26-02-2021 init version 1.0
*/

defined('_JEXEC') or die;
jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.filesystem.file');
jimport( 'joomla.html.parameter' );

JLoader::registerPrefix('Phocacart', JPATH_ADMINISTRATOR . '/components/com_phocacart/libraries/phocacart');

if (!class_exists('DigiwalletCore')) {
    require(JPATH_SITE . '/plugins/pcp/digiwallet_bancontact/helpers/digiwallet.class.php');
}

class plgPCPDigiwallet_Bancontact extends JPlugin
{
    const DIGIWALLET_API = 'https://api.digiwallet.nl/';
    const DIGIWALLET_CURRENCY = 'EUR';
    const DIGIWALLET_BANKWIRE_METHOD = 'BW';
    const DIGIWALLET_EPS_METHOD = 'EPS';
    const DIGIWALLET_GIP_METHOD = 'GIP';
    
    public $payMethod = "MRC";
    public $payMethodName = "Bancontact";
    public $salt = 'e381277';
    public $dwTable = '#__digiwallet';
    
    function __construct(& $subject, $config) {
        
        parent :: __construct($subject, $config);
        $this->loadLanguage();
    }
    
    /**
     * Proceed to payment - some method do not have proceed to payment gateway like e.g. cash on delivery
     *
     * @param   integer	$proceed  Proceed or not proceed to payment gateway
     * @param   string	$message  Custom message array set by plugin to override standard messages made by component
     *
     * @return  boolean  True
     */
    
    function PCPbeforeProceedToPayment(&$proceed, &$message) {
        $app         = JFactory::getApplication();
        $session     = JFactory::getSession();
        $guest = PhocacartUserGuestuser::getGuestUser();
        $payment_id = 0;
        if ($guest) {
            $payment_id = $session->get('guestpayment', false, 'phocaCart');
            
        } else {
            if (is_callable(['PhocacartUser', 'getUser'])) {
                $user = PhocacartUser::getUser();
            } else {
                $user = JFactory::getUser();
            }
            $cartDb = PhocacartCartDb::getCartDb((int)$user->id);
            $payment_id = $cartDb['payment'];
        }
        if ($payment_id > 0) {
            $paymentObject = new PhocacartPayment();
            if (is_callable(['PhocacartPayment', 'setType'])) {
                $paymentObject->setType(2);
            }
            $paymentInfo = $paymentObject->getPaymentMethod($payment_id);
        }
        
        if (empty($paymentInfo->params['dw_' . strtolower($this->payMethod) . '_rtlo'])) {
            $app->enqueueMessage(JText::_('PLG_PCP_DIGIWALLET_MISSING_RTLO'), 'warning');
            $app->redirect(JURI::root(false). 'index.php?option=com_phocacart&view=checkout&task=order');
            exit();
        }
        if (empty($paymentInfo->params['dw_' . strtolower($this->payMethod) . '_token']) && in_array($this->payMethod, ['EPS', 'GIP'])) {
            $app->enqueueMessage(JText::_('PLG_PCP_DIGIWALLET_MISSING_TOKEN'), 'warning');
            $app->redirect(JURI::root(false). 'index.php?option=com_phocacart&view=checkout&task=order');
            exit();
        }
        $proceed = 1;
        $message = array();
        return true;
    }
    
    function PCPbeforeSetPaymentForm(&$form, $paramsC, $params, $order) {
        $session 	= JFactory::getSession();
        $infoaction = $session->get('infoaction', false, 'phocaCart');
        $document = JFactory::getDocument();
        $rtlo = $params->get('dw_' . strtolower($this->payMethod) . '_rtlo', 0);
        $token = $params->get('dw_' . strtolower($this->payMethod) . '_token', 0);
        $paramsC = PhocacartUtils::getComponentParameters();
        $rounding_calculation = $paramsC->get( 'rounding_calculation', 1 );
        $price = new PhocacartPrice();
        $b = $order['bas']['b'];

        $r = 1;
        if (isset($order['common']->currency_exchange_rate)) {
            $r = $order['common']->currency_exchange_rate;
        }
        
        if (isset($order['common']->payment_id) && (int)$order['common']->payment_id > 0) {
            $paymentId = (int)$order['common']->payment_id;
        } else {
            $paymentId = 0;
        }
        $orderId = $order['common']->id;
        $return = $notify_url = JURI::root(false). "index.php?option=com_phocacart&view=response&task=response.paymentnotify&type=" . strtolower($this->_name) . "&od={$orderId}&pid={$paymentId}&tmpl=component&infoaction={$infoaction}";
        $cancel_return = JURI::root(false). "index.php?option=com_phocacart&view=response&task=response.paymentcancel&type=" . strtolower($this->_name) . "&mid=1";
        // There can be difference between cart total amount and payment total amount (because of currency and its rounding)
        // cart total amount (brutto) 	= (item * quantity) * currency rate
        // payment total amount			= (item * currency rate) * quantity
        $cartBrutto = 0;// Total amount (brutto) calculated by cart
        $paymentBrutto = 0;// Total amount (brutto) calculated by payment method
        $discountAmount = 0;// Sum of all discount values - all MINUS values
        $currencyAmount = 0;
        foreach ($order['products'] as $v) {
            $paymentBrutto = $paymentBrutto + (($price->roundPrice($v->netto * $r)) * (int)$v->quantity);
        }
        
        foreach ($order['total'] as $v) {
            if ($v->amount != 0 || $v->amount_currency != 0) {
                
                switch($v->type) {
                    
                    // All discounts (MINUS)
                    case 'dnetto':
                        $paymentBrutto 		+= $price->roundPrice($v->amount * $r);
                        $discountAmount 	+= $price->roundPrice(abs($v->amount * $r));
                        break;
                        
                        // Tax (PLUS)
                    case 'tax':
                        $paymentBrutto 		+= $price->roundPrice($v->amount * $r);
                        break;
                        
                        // Payment Method, Shipping Method (PLUS)
                    case 'sbrutto':
                    case 'pbrutto':
                        $paymentBrutto 		+= $price->roundPrice($v->amount * $r);
                        break;
                        // Rounding (PLUS/MINUS)
                    case 'rounding':
                        if ($v->amount_currency != 0) {
                            // Rounding is set in order currency
                            if ($v->amount_currency > 0) {
                                $currencyAmount		+= round($v->amount_currency, 2, $rounding_calculation);
                                $paymentBrutto 		+= round($v->amount_currency, 2, $rounding_calculation);
                            } else if ($v->amount_currency < 0) {
                                $discountAmount 	+= round(abs($v->amount_currency), 2, $rounding_calculation);
                                $paymentBrutto 		+= round($v->amount_currency, 2, $rounding_calculation);
                            }
                        } else {
                            // Rounding is set in default currency
                            if ($v->amount > 0 && round(($v->amount * $r), 2, $rounding_calculation) > 0) {
                                $paymentBrutto 		+= round(($v->amount * $r), 2, $rounding_calculation);
                            } else if ($v->amount < 0) {
                                $discountAmount 	+= round(abs($v->amount * $r), 2, $rounding_calculation);
                                $paymentBrutto 		+= round(($v->amount * $r), 2, $rounding_calculation);
                            }
                        }
                        break;
                        // Brutto (total amount)
                    case 'brutto':
                        if ($v->amount_currency != 0) {
                            // Brutto is set in order currency
                            $cartBrutto = $price->roundPrice($v->amount_currency);
                        } else {
                            // Brutto is set in default currency
                            $cartBrutto = $price->roundPrice($v->amount * $r);
                        }
                        break;
                }
            }
        }
        
        if ($cartBrutto > $paymentBrutto) {
            $currencyAmount		+= ($cartBrutto - $paymentBrutto);
            
        } else if ($cartBrutto < $paymentBrutto) {
            
            // in PayPal - if currency rounding minus then make it as a part of discount
            $discountAmount 	+= ($paymentBrutto - $cartBrutto);
        }
        
        $discountAmount = $price->roundPrice($discountAmount);
        $amount = $paymentBrutto;
        $description = "Phoca order: $orderId";
        $digiWallet = new DigiwalletCore($this->payMethod, $rtlo, $params->get('language', 'nl'));
        $digiWallet->setAmount($amount * 100);
        $digiWallet->setDescription($description);
        $digiWallet->setReturnUrl($return);
        $digiWallet->setReportUrl($notify_url);
        $digiWallet->bindParam('email', $b['email']);
        $this->additionalParameters($order, $digiWallet, $amount);
        $result = $bankUrl = $digiWallet->startPayment();
        $message = $digiWallet->getErrorMessage();
        $transactionId = $digiWallet->getTransactionId();
        $requestParams = $digiWallet->url;
        
        if ($result == false) {
            $app = JFactory::getApplication();
            $app->enqueueMessage($message, 'warning');
            $app->redirect($cancel_return);
        }
        $data = [];
        $data["order_id"] = $orderId;
        $data["rtlo"] = $rtlo;
        $data["paymethod"] = $this->payMethod;
        $data["transaction_id"] = $transactionId;
        $data["request"] = $requestParams;
        $data["amount"] = $amount;
        $data["bank_url"] = $bankUrl;
        $this->__storeDigiwalletRequestData($data);
        
        $f		= array();
        $f[]	= '<div class="ph-center">';
        $f[]	= '<div>'.JText::_('COM_PHOCACART_ORDER_SUCCESSFULLY_PROCESSED').'</div>';
        $f[]	= '<div>'.JText::_('PLG_PCP_DIGIWALLET_YOU_ARE_NOW_BEING_REDIRECTED_TO_DIGIWALLET').'</div>';
        
        $f[]	= '<div class="ph-loader"></div>';
        
        $f[]	= '<div>'.JText::_('PLG_PCP_DIGIWALLET_IF_YOU_ARE_NOT_REDIRECTED_WITHIN_A_FEW_SECONDS_PLEASE').' ';
        $f[]	= '<a class="btn btn-primary" href="'.$bankUrl.'" class="button">'.JText::_('PLG_PCP_DIGIWALLET_CLICK_HERE_TO_BE_REDIRECTED_TO_DIGIWALLET').'</a>';
        $f[]	= '</div>';
        $f[]	= '</div>';
        $form	= implode("\n", $f);
        
        $js		= 'window.onload=function(){window.setTimeout(window.location.href = "'. $bankUrl . '", 1100)};';
        $document->addScriptDeclaration($js);
        PhocacartLog::add(1, 'Payment - GO TO DIGIWALLET', (int)$order['common']->id, $form);
        
        return false;
    } 
    
    function PCPbeforeCheckPayment($pid) {
        $paymentTemp		= new PhocacartPayment();
        $paymentOTemp 		= $paymentTemp->getPaymentMethod((int)$pid );
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->processReport($paymentOTemp);
        } else {
            $this->processReturn($paymentOTemp);
        }
    }
    
    /**
     * Process report
     * checkPayment from api & update status
     */
    private function processReport($paymentOTemp)
    {
        $jinput = JFactory::getApplication()->input;
        $trxid = $jinput->getString('trxid', 0);
        $digiwalletInfo = $this->__retrieveDigiwalletInformation("transaction_id = '" . $trxid. "'");
        if (!$digiwalletInfo) {
            echo "Transaction {$trxid} does not exist." . "\n", die;
        }
        if ($digiwalletInfo->success == 0) {
            $message = $this->checkPayment($digiwalletInfo, $paymentOTemp);
            echo $message . "\n";
        } else {
            echo "Transaction {$trxid} had been done." . "\n";
        }
        die('Done');
    }
    
    /**
     * Process return url
     * check status & redirect to result page
     */
    private function processReturn($paymentOTemp)
    {
        $app = JFactory::getApplication();
        $jinput = JFactory::getApplication()->input;
        $trxid = $jinput->getString('trxid', 0);
        $digiwalletInfo = $this->__retrieveDigiwalletInformation("transaction_id = '" . $trxid. "'");
        if (!$digiwalletInfo) {
            $app->redirect(JURI::root(false));
            exit();
        }
        if ($digiwalletInfo->success == 0) {
            $this->checkPayment($digiwalletInfo, $paymentOTemp, false);
            $digiwalletInfo = $this->__retrieveDigiwalletInformation("transaction_id = '" . $trxid. "'");
        }
        $session = JFactory::getSession();
        if ($digiwalletInfo->success == 0) {
            $session->set('infoaction', 5, 'phocaCart');
            $session->set('infomessage', ['payment_canceled' => JText::_('COM_PHOCACART_DIGIWALLET_PAYMENT_FAILED')], 'phocaCart');
        } else {
            $action = $jinput->getString('infoaction', 0);
            $session->set('infoaction', $action, 'phocaCart');
        }
        $app->redirect(JURI::root(false). 'index.php?option=com_phocacart&view=response&task=response.paymentrecieve');
    }
    
    public function checkPayment($digiwalletInfo, $paymentOTemp, $report = true)
    {
        $response = $report ? json_encode($_POST) : json_encode($_GET);
        $id = $digiwalletInfo->order_id;
        $comment = '';
        $digiwallet = new DigiwalletCore($digiwalletInfo->paymethod, $digiwalletInfo->rtlo);
        $digiwallet->checkPayment($digiwalletInfo->transaction_id, $this->getAdditionParametersReport($digiwalletInfo));
        $isSuccess = $digiwallet->getPaidStatus();
        $errorMessage = $digiwallet->getErrorMessage();
        
        if ($isSuccess) { //success
            $newStatus = $paymentOTemp->params->get('dw_' . strtolower($this->payMethod) . '_status_success', 0);
            $amountPaid = $digiwalletInfo->amount;
            // Add log
            $msg = 'Order Id: '. $id . " \n"
                . 'Trx Id: '.$digiwalletInfo->transaction_id. " \n"
                    . 'Message: Payment successfully made'. " \n"
                        //. 'POST: '.$val. " \n"
            . 'Response: '. $response;
            PhocacartLog::add(1, "Payment - {$this->payMethodName} - SUCCESS", (int)$id, $msg);
            $this->updatePaymentInfo([
                    "`paid_amount`={$amountPaid}, `success`=1, `response` = '{$response}'"
                ], $digiwalletInfo->transaction_id);
            
            $comment	= JText::_('COM_PHOCACART_ORDER_STATUS_CHANGED_BY_PAYMENT_SERVICE_PROVIDER') . "({$this->payMethodName})";
            $comment .= "\n" . JText::_('COM_PHOCACART_INFORMATION');
            $comment .= "\n". JText::_('COM_PHOCACART_PAYMENT_ID'). ': '. $digiwalletInfo->transaction_id;
            $comment .= "\n". JText::_('COM_PHOCACART_PAYMENT_AMOUNT'). ': '. $amountPaid;
            $comment .= "\n". JText::_('COM_PHOCACART_PAYMENT_STATUS'). ': '. $newStatus;
        } else {
            $newStatus = $paymentOTemp->params->get('dw_' . strtolower($this->payMethod) . '_status_failed', 0);
            PhocacartLog::add(1, "Payment - {$this->payMethodName} - FAILED", (int)$id, $errorMessage);
            $this->updatePaymentInfo([
                "`response` = '{$response}'"
            ], $digiwalletInfo->transaction_id);
        }
        
        $order 			= new PhocacartOrderView();
        $o				= array();
        $o['common']	= $order->getItemCommon($id);
        $o['total'] 	= $order->getItemTotal($id);
        if (PhocacartOrderStatus::changeStatusInOrderTable((int)$id, $newStatus)) {
            PhocacartLog::add(1, "Payment - {$this->payMethodName} - Order Status Change", (int)$id, 'Order status changed to: '. $newStatus);
        }
        $notify = false;
        try {
            $notify 	= PhocacartOrderStatus::changeStatus((int)$id, (int)$newStatus, $o['common']->order_token);
        } catch (RuntimeException $e) {
            PhocacartLog::add(1, "Payment - {$this->payMethodName} - ERROR", (int)$id, $e->getMessage());
        }
        
        // Add status history
        PhocacartOrderStatus::setHistory((int)$id, (int)$newStatus, (int)$notify, $comment);
        
        $oldStatus = PhocacartOrderStatus::getStatus($o['common']->status_id);
        $newStatus = PhocacartOrderStatus::getStatus($newStatus);
        $message = "Order {$id}.\n";
        $message .= "Order status changed from {$oldStatus['title']} to {$newStatus['title']}";
        return $message;
    }
    
    /**
     * Insert payment info into table #__digiwallet
     *
     * @param unknown $data
     * @return mixed
     */
    private function __storeDigiwalletRequestData($data)
    {
        // Get a db connection.
        $db = JFactory::getDbo();
        
        // Create a new query object.
        $query = $db->getQuery(true);
        
        foreach ($data as $key => $value) {
            $columns[] = $key;
            $values[] = $db->quote($value);
        }
        
        // Prepare the insert query.
        $query->insert($db->quoteName($this->dwTable))
        ->columns($db->quoteName($columns))
        ->values(implode(',', $values));
        
        // Reset the query using our newly populated query object.
        $db->setQuery($query);
        $db->execute();
        return $db->insertid();
    }
    
    /**
     * Update digiwallet table
     *
     * @param string $trxid
     *
     * @return mixed
     */
    private function updatePaymentInfo($set, $trxid)
    {
        // Get a db connection.
        $db = JFactory::getDbo();
        
        // Create a new query object.
        $query = $db->getQuery(true);
        // Prepare the update query.
        $query->update($db->quoteName($this->dwTable))
        ->set($set)
        ->where("transaction_id = '" . $trxid . "'");
        // Reset the query using our newly populated query object.
        $db->setQuery($query);
        return $db->execute();
    }
    
    /**
     * Get payment info in table __digiwallet
     *
     * @param string $trxid
     * @return mixed|void|NULL
     */
    private function __retrieveDigiwalletInformation($cond)
    {
        // Get a db connection.
        $db = JFactory::getDbo();
        
        // Create a new query object.
        $query = $db->getQuery(true);
        
        // Select all records from the user profile table where key begins with "custom.".
        // Order it by the ordering field.
        $query->select(array(
            'id',
            'order_id',
            'rtlo',
            'paymethod',
            'transaction_id',
            'paid_amount',
            'amount',
            'bank_url',
            'request',
            'response',
            'success'
        ));
        
        $query->from($this->dwTable);
        $query->where($cond);
        
        // Reset the query using our newly populated query object.
        $db->setQuery($query);
        $db->execute();
        // Load the results as a list of stdClass objects.
        return $db->loadObject();
    }
    
    /**
     * addition params for report
     * @return array
     */
    protected function getAdditionParametersReport($paymentTable)
    {
        $param = [];
        if ($paymentTable->paymethod== self::DIGIWALLET_BANKWIRE_METHOD) {
            $checksum = md5($paymentTable->transaction_id. $paymentTable->rtlo. $this->salt);
            $param['checksum'] = $checksum;
        }
        
        return $param;
    }
    
    /**
     *  Bind parameters
     */
    public function additionalParameters($order, $digiwalletObj, $total)
    {
        return true;
    }
    
    /***
     * Get user's ip address
     * @return mixed
     */
    public function getCustomerIP()
    {
        if(!empty($_SERVER['HTTP_CLIENT_IP'])){
            //ip from share internet
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }else{
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return $ip;
    }
}
