CREATE TABLE IF NOT EXISTS `#__digiwallet` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `order_id` varchar(50) NOT NULL DEFAULT '0',
    `rtlo` int(11) NOT NULL,
    `paymethod` varchar(8) NOT NULL DEFAULT 'IDE',
    `transaction_id` varchar(50) NOT NULL,
    `amount` decimal(11,2) NOT NULL DEFAULT '0.00',
    `paid_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
    `bank_url` varchar(1000) DEFAULT NULL,
    `request` TEXT DEFAULT NULL,
    `response` TEXT DEFAULT NULL,
    `success` TINYINT(1) NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY `order_id` (`order_id`),
    KEY `transaction_id` (`transaction_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;
